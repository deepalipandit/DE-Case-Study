'''
Created on Oct 24, 2019

@author: Student
'''
import os
from pyspark.sql import SparkSession

class ETLMySQLMongoDB:

    def __init__(self):
        os.environ['PYSPARK_SUBMIT_ARGS'] = "--packages 'org.mongodb.spark:mongo-spark-connector_2.11:2.4.1' pyspark-shell"
        self.spark = SparkSession.builder.getOrCreate()


    def read_table_from_mysql(self, table_name_param):
        jdbcDF = self.spark.read \
                                    .format("jdbc") \
                                    .option("driver","com.mysql.cj.jdbc.Driver") \
                                    .option("url", "jdbc:mysql://localhost:3306/cdw_sapp") \
                                    .option("dbtable", table_name_param) \
                                    .option("user", "root") \
                                    .option("password", "root") \
                                    .load()
        return jdbcDF
    
    def write_to_mongo(self, collection_name_param, jdbcDF_param, transformation_string_param):
        jdbcDF_param.createOrReplaceTempView('tempview')
        transformed_df = self.spark.sql(transformation_string_param + ' from tempview')
        transformed_df.show()
        transformed_df.write \
                               .format("mongo") \
                               .mode("overwrite") \
                               .option('uri', "mongodb://localhost:27017") \
                               .option('database','credit_card') \
                               .option("collection", collection_name_param) \
                               .save()

