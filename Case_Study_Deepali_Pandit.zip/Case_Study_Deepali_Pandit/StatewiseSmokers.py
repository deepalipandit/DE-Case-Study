'''
Created on Oct 26, 2019

@author: Student
'''
import pymongo

import matplotlib.pyplot as plt
import pandas as pd

class StatewiseSmokers:
    def __init__(self):
        plt.style.use('ggplot')
        self.myclient = pymongo.MongoClient("mongodb://localhost:27017/")
        self.mydb = self.myclient["health_insuarance_market_place"]
        self.mycollection = self.mydb["insurance"]

    def plot_date(self):
        female_smokers_with_children_cur = self.mycollection.aggregate( \
                                                           [ \
                                                            { "$match": { "sex": "female" } }, \
                                                            { "$match": { "children": {"$gt": 0} } },
                                                            { "$group": {
                                                                "_id": { "region": "$region"},
                                                                "count": { "$sum": 1 }
                                                            } } 
                                                            ] )

        regions_list = []
        for females in female_smokers_with_children_cur:
            regions_list.append(females['_id']['region'])

        df_se = pd.DataFrame( list(\
                      self.mycollection.aggregate( [ \
                                                            { "$match": { "smoker": "yes" } }, \
                                                            { "$group": {
                                                                "_id": { "region": "$region"},
                                                                "count": { "$sum": 1 }
                                                            } } 
                                                            ] ) ), index = regions_list )

        df_se.plot.bar(figsize=(7,5))
        plt.ylabel("No. Of Smokers")
        plt.xlabel("Regions")
        plt.title("Region wise No. Of Smokers")
        plt.subplots_adjust(bottom=0.25)
        plt.show()