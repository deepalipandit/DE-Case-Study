'''
Created on Oct 18, 2019

@author: Student
'''
import requests, os
from kafka import KafkaProducer
from pyspark.sql import SparkSession

class ETLKafkaSparkMongo:

    def __init__(self):
        os.environ['PYSPARK_SUBMIT_ARGS'] = "--packages 'org.apache.spark:spark-sql-kafka-0-10_2.11:2.4.1','org.mongodb.spark:mongo-spark-connector_2.11:2.4.1' pyspark-shell"
        self.spark = SparkSession.builder.getOrCreate()
        self.producer = KafkaProducer(bootstrap_servers='localhost:9092')



    def kafka_topic_producer(self, topic_name_param, topic_url):
        response = requests.get(topic_url)
        response_text = response.text
        data_list = [line for line in response_text.splitlines()[1:]]
        for record in data_list:
            self.producer.send(topic_name_param,record.encode('utf-8'))
        self.producer.flush()


    def read_kafka_topic_to_rdd(self, topic_name_param, split_param):
    
        raw_kafka_df = self.spark \
                    .readStream \
                    .format('kafka') \
                    .option("kafka.bootstrap.servers","localhost:9092") \
                    .option("subscribe",topic_name_param) \
                    .option("startingOffsets", "earliest") \
                    .load()
    
        kafka_value_df = raw_kafka_df.selectExpr("CAST(value AS STRING)")
        del raw_kafka_df
    
        output_query = kafka_value_df.writeStream \
                         .queryName("queryName") \
                         .format("memory") \
                         .start()
        output_query.awaitTermination(10)
        del kafka_value_df
    
        value_df = self.spark.sql("select * from queryName")

        value_rdd = value_df.rdd.map(lambda i: i['value'].split(split_param))
        return value_rdd

    def write_rdd_to_mongodb(self, row_rdd_param, db_name_param, collection_name_param,mode_param):     
        df = self.spark.createDataFrame(row_rdd_param)
    
        df.write \
            .format("mongo") \
            .mode(mode_param) \
            .option('uri', "mongodb://localhost:27017") \
            .option('database',db_name_param) \
            .option("collection", collection_name_param) \
            .save()
