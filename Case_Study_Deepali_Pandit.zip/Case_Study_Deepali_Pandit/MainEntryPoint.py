'''
Created on Oct 26, 2019

@author: Student
'''
from pyspark.sql import Row
from ETLKafkaSparkMongo import ETLKafkaSparkMongo
 
from ETLMySQLMongoDB import ETLMySQLMongoDB
from StatewiseSources import StatewiseSources
from SmokerMothers import SmokerMothers
from StatewiseSmokers import StatewiseSmokers

def main():
    print('Welcome to My Case Study!')
   
    entry=None
    # While User has not entered 4 i.e Quit
    while entry!='4':

        entry = input('\n1. Read credit card data from MariaDB To MongoDB\n2. Read Health Insurance Marketplace website data to MongoDB. \
                            \n3. Some Visualizations of the data we loaded to MongoDb \n4. Quit\n\nPlease, enter 1, 2, 3 or 4: ')
        
        # If User selects 1. Read credit card data from MariaDB To MongoDB option
        if entry=='1':
            print('Loading Data. This may take a while. Please wait ..........')
            credit_card_etl = ETLMySQLMongoDB()
            # Get Branch Details from MySQL to branch collection in MongoDB
            jdbc_df = credit_card_etl.read_table_from_mysql('cdw_sapp_branch')
            select_query ='select BRANCH_CODE, BRANCH_NAME, BRANCH_STREET, BRANCH_CITY, BRANCH_STATE, \
                                            CONCAT("(", substring(BRANCH_PHONE,1,3),")", substring(BRANCH_PHONE,4,3),"-", substring(BRANCH_PHONE,7)) as BRANCH_PHONE, \
                                            if(isnotnull(BRANCH_ZIP), BRANCH_ZIP, 99999) as BRANCH_ZIP,LAST_UPDATED'
            credit_card_etl.write_to_mongo('branches', jdbc_df, select_query)

            # Get Customer Details from MySQL to customer collection in MongoDB
            jdbc_df = credit_card_etl.read_table_from_mysql('cdw_sapp_customer')
            select_query = "select SSN, initcap(FIRST_NAME), lower(MIDDLE_NAME), initcap(LAST_NAME), CREDIT_CARD_NO, \
                                            concat(APT_NO, ' ', STREET_NAME) as STREET, CUST_CITY, CUST_STATE, CUST_COUNTRY, \
                                            CUST_ZIP, concat(substring(CUST_PHONE,1,3), '-', substring(CUST_PHONE,4)) as CUST_PHONE, \
                                            CUST_EMAIL, LAST_UPDATED"
    
            credit_card_etl.write_to_mongo('customers',jdbc_df,select_query)

            # Get Transaction Details from MySQL to credit_card collection in MongoDB
            jdbc_df = credit_card_etl.read_table_from_mysql('cdw_sapp_creditcard')
            select_query = 'select CREDIT_CARD_NO, CONCAT(YEAR,MONTH,DAY) as TIMEID \
                                            ,CUST_SSN,BRANCH_CODE,TRANSACTION_TYPE,TRANSACTION_VALUE,TRANSACTION_ID'
            credit_card_etl.write_to_mongo('transactions', jdbc_df, select_query)

        # If User selects 2. Read Health Insurance Marketplace website data to MongoDB. option
        elif entry=='2':
            print('Loading Data. This may take a while. Please wait ..........')
            health_etl = ETLKafkaSparkMongo()
            health_etl.kafka_topic_producer('Network','https://raw.githubusercontent.com/platformps/Healthcare-Insurance-Data/master/Network.csv')                    
            health_etl.kafka_topic_producer('ServiceArea','https://raw.githubusercontent.com/platformps/Healthcare-Insurance-Data/master/ServiceArea.csv')
            health_etl.kafka_topic_producer('Insurance','https://raw.githubusercontent.com/platformps/Healthcare-Insurance-Data/master/insurance.txt')
            health_etl.kafka_topic_producer('PlanAttributes','https://raw.githubusercontent.com/platformps/Healthcare-Insurance-Data/master/PlanAttributes.csv')
            health_etl.producer.close()
        
            # Network topic from kafka to network collection in MongoDB
            value_rdd = health_etl.read_kafka_topic_to_rdd("Network", ",")
            row_rdd = value_rdd.map(lambda i: Row( \
                                              business_year    = int ( i [ 0 ] ) , \
                                              state_code         = i [ 1 ] , \
                                              issuer_id            = int ( i [ 2 ] ) , \
                                              source_name     = i [ 3 ] , \
                                              version_num      = i [ 4 ] , \
                                              import_date       = i [ 5 ] , \
                                              issuer_id_2         = int ( i [ 6 ] ) , \
                                              state_code_2      = i [ 7 ] , \
                                              network_name    = i [ 8 ] , \
                                              network_id         = i [ 9 ] , \
                                              network_url         = i [ 10 ] , \
                                              row_number        = i [ 11 ]  , \
                                              market_coverage = i [ 12 ] , \
                                              dental_only_plan = i [ 13 ] ) )
            del value_rdd
            health_etl.write_rdd_to_mongodb(row_rdd, "health_insurance_market_place", "network","overwrite")
    
            # ServiceArea topic from kafka to network collection in MongoDB
            value_rdd = health_etl.read_kafka_topic_to_rdd("ServiceArea", ",")
        
            row_rdd = value_rdd.map(lambda i: Row( \
                                                           Business_year = int ( i [ 0 ] ) , \
                                                           state_code = i [ 1 ] , \
                                                           issuer_id = int ( i [ 2 ] ) , \
                                                           source_name = i [ 3 ] , \
                                                           version_num = i [ 4 ] , \
                                                           import_date = i [ 5 ] , \
                                                           issuer_id_2 = int ( i [ 6 ] ) , \
                                                           state_code_2 = i [ 7 ] , \
                                                           service_area_id = i [ 8 ] , \
                                                           service_area_name = i [ 9 ] , \
                                                           cover_entire_state = i [ 10 ] , \
                                                           county = i [ 11 ] , \
                                                           partial_county = i [ 12  ] , \
                                                           zip_codes = i [ 13  ] , \
                                                           partial_county_justification = i [ 14  ] , \
                                                           row_number = i [ 15  ] , \
                                                           market_coverage = i [ 16  ] , \
                                                           dental_only_plan = i [ 17 ] ) )     
            del value_rdd
            health_etl.write_rdd_to_mongodb(row_rdd, "health_insurance_market_place", "service_area","overwrite")

            # Insurance topic from kafka to insurance collection in MongoDB
            value_rdd = health_etl.read_kafka_topic_to_rdd("Insurance", "\t")
            row_rdd = value_rdd.map(lambda i: Row( \
                                                           age = int ( i [ 0  ] ) , \
                                                           sex = i [ 1  ] , \
                                                           bmi = float ( i [ 2  ] ) , \
                                                           children = int ( i [ 3  ] ) , \
                                                           smoker = i [  4 ] , \
                                                           region = i [  5 ] , \
                                                           charges = float ( i [ 6  ] ) ) )
 
            del value_rdd
            health_etl.write_rdd_to_mongodb(row_rdd, "health_insurance_market_place", "insurance","overwrite")

            # PlanAttributes topic from kafka to plan_attributes collection in MongoDB
            value_rdd = health_etl.read_kafka_topic_to_rdd("PlanAttributes", "\t")
         
            row_rdd = value_rdd.map(lambda i: Row( \
                                                           attributes_id =int ( i [ 0 ] ) , \
                                                           begin_primary_care_cost_sharing_after_number_of_visits = int ( i [ 1 ] ) , \
                                                           begin_primary_care_deductible_coinsurance_after_number_of_copays = int ( i [ 2 ] ) , \
                                                           benefit_package_id = int ( i [ 3 ] ) , \
                                                           business_year = int ( i [ 4 ] ) , \
                                                           child_only_offering = i [ 5 ] , \
                                                           composite_rating_offered = i [ 6 ] , \
                                                           csr_variation_type = i [ 7 ] , \
                                                           dental_only_plan = i [ 8 ] , \
                                                           disease_management_programs_offered = i [ 9 ] , \
                                                           first_tier_utilization = i [ 10 ] , \
                                                           hsa_or_hra_employer_contribution = i [ 11 ] , \
                                                           hsa_or_hra_employer_contribution_amount = i [ 12 ] , \
                                                           inpatient_copayment_maximum_days = int ( i [ 13 ] ) , \
                                                           is_guaranteed_rate = i [ 14 ] , \
                                                           is_hsa_eligible = i [ 15 ] , \
                                                           is_new_plan = i [ 16 ] , \
                                                           is_notice_required_for_pregnancy = i [ 17 ] , \
                                                           is_referral_required_for_specialist = i [ 18 ] , \
                                                           issuer_id = int ( i [ 19 ] ) , \
                                                           market_coverage = i [ 20 ] , \
                                                           medical_drug_deductibles_integrated = i [ 21 ] , \
                                                           medical_drug_maximum_outof_pocket_integrated = i [ 22 ] , \
                                                           metal_level = i [ 23 ] , \
                                                           multiple_in_network_tiers = i [ 24 ] , \
                                                           national_network = i [ 25 ] , \
                                                           network_id = i [ 26 ] , \
                                                           out_of_country_coverage = i [ 27 ] , \
                                                           out_of_service_area_coverage = i [ 28 ] , \
                                                           plan_effective_date = i [ 29 ] , \
                                                           plan_expiration_date = i [ 30 ] , \
                                                           plan_id = i [ 31 ] , \
                                                           plan_level_exclusions = i [ 32 ] , \
                                                           plan_marketing_name = i [ 33 ] , \
                                                           plan_type = i [ 34 ] , \
                                                           qhp_non_qhp_type_id = i [ 35 ] , \
                                                           second_tier_utilization = i [ 36 ] , \
                                                           service_area_id = i [ 37 ] , \
                                                           source_name = i [ 38 ] , \
                                                           specialty_drug_maximum_coinsurance = i [ 39 ] , \
                                                           standard_component_id = i [ 40 ] , \
                                                           state_code = i [ 41 ] , \
                                                           wellness_program_offered = i [ 42 ] ) )
 
            del value_rdd
            health_etl.write_rdd_to_mongodb(row_rdd, "health_insurance_market_place", "plan_attributes","overwrite")

        # If User selects 3. Some Visualizations of the data we loaded to MongoDb 
        elif entry=='3':
            print("\n\nNow that we have loaded data in our MongoDB. Let's head for some visulization's")
            visual_entry = ''
            while visual_entry!='4':

                visual_entry = input('\n1. Sources​ across the country.\n2. Number of mothers who smoke and also have children.\
                                                    \n3. Region wise smokers.\n4.  Quit \nPlease, enter 1, 2, 3 or 4: ')
                print(visual_entry)
                # If User selects 1. Read credit card data from MariaDB To MongoDB option
                if visual_entry=='1':
                    state_source = StatewiseSources()
                    state_source.plot_data()
                elif visual_entry=='2':
                    smoker_mothers = SmokerMothers()
                    smoker_mothers.plot_data()
                elif visual_entry=='3':
                    statewise_smokers = StatewiseSmokers()
                    statewise_smokers.plot_date()
                elif visual_entry!='4':
                    print('\nInvalid Option...')
        elif entry!='4':
            print('\nInvalid Option...')
    print('\nClosing Program. Goodbye.')
    
if __name__=='__main__':
    try:
        main()
    except Exception as e:
        print("Oops Something went wrong somewhere.....!")
        print('\n\nPython error message .............')
        print(f'\n\n{e}')
