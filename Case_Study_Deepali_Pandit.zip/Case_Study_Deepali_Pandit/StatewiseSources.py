'''
Created on Oct 26, 2019

@author: Student
'''
import pymongo
import matplotlib.pyplot as plt
import pandas as pd

class StatewiseSources:
    def __init__(self):
        plt.style.use('ggplot')
        self.myclient = pymongo.MongoClient("mongodb://localhost:27017/")
        self.mydb = self.myclient["health_insuarance_market_place"]
        self.mycollection = self.mydb["service_area"]

    def plot_data(self):
        states_sources_cur = self.mycollection.aggregate( \
                                            [ \
                                                { "$group": { \
                                                    "_id": { \
                                                    "state_code": "$state_code", \
                                                    "source_name": "$source_name" \
                                                }, \
                                                    "count": { "$sum": 1 } \
                                                } }])

        states_sources_names_list = []
        for state_source in states_sources_cur:
            states_sources_names_list.append(state_source['_id']['state_code'] + ' ' + state_source['_id']['source_name'])

        df_se = pd.DataFrame( list(\
                                   self.mycollection.aggregate( \
                                                                    [ \
                                                                     { "$group": { \
                                                                       "_id": { \
                                                                               "state_code": "$state_code", \
                                                                               "source_name": "$source_name" \
                                                                               }, \
                                                                       "count": { "$sum": 1 } \
                                                                    } }])), index = states_sources_names_list)

        df_se.plot.bar(figsize=(15,7))
        plt.ylabel("No. Of Sources")
        plt.xlabel("States & Sources")
        plt.title("Sources Across The Country")
        plt.subplots_adjust(bottom=0.25)
        plt.show()